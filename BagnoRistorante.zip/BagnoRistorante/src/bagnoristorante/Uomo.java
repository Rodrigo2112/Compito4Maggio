/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bagnoristorante;
import java.util.concurrent.*;

/**
 *
 * @author informatica
 */
public class Uomo implements Runnable {

    private final String nomeU;

    public Uomo(String nomeU) {
        this.nomeU = nomeU;
    }
    
    
    @Override
    public void run() {
        
    }
    
}
